print("Jay Ganesh")

no = 10

if no > 0:
    print("Number is Posititve")
elif no == 0:
    print("Number is Zero")
else:
    print("NUmber is negative")
    