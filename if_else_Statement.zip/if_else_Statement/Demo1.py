print("-----jay ganesh-----")

no = 11
if no > 10:
    print("Number is greater than 10")