print("Jay Ganesh")

no = 20

if no >= 0:
    print("Number is Positive")
else:
    print("Number is Negative")
