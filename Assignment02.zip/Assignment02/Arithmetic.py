#module Arithmetic

from typing import AnyStr


def Add(no1,no2):
    
    ans = no1 + no2
    print("Additon of 2 Numbers :",ans)

def Sub(no1,no2):
    
    ans = no1 - no2
    print("Substraction of 2 Numbers :",ans)

def Mult(no1,no2):
    
    ans = no1 * no2
    print("Multiplication of 2 Numbers :",ans)

def Div(no1,no2):
    
    ans = no1/no2
    print("Division of 2 Numbers :",ans)