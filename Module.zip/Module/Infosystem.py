def Substraction(value1,value2):
    print("Inside module :",__name__)
    result=0
    result = value1-value2
    return result
def Addition(value1,value2):   #   Addition(10,11)
    print("Inside module :",__name__)
    result=0
    result = value1+value2
    return result
