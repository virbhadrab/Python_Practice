#import Marvellous 
from Marvellous import *
#import Marvellous as m
from Infosystem import *
#import Infosystem

def main():
    print("Inside module : ",__name__)
    no1 = int(input("Enter 1st no."))   #10
    no2 = int(input("Enetr 2nd no."))   #11

    ret = Addition(no1,no2) # Addition(10,11)
    print("Additon is :",ret)
    
    ret = Substraction(no1,no2)

    print("Substraction is :",ret)

if __name__=="__main__":
    main()