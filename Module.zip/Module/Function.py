def Arithmatic(value1,value2):
    add = value1 + value2
    sub = value1 - value2
    mult = value1 * value2
    div = value1 / value2
    return add,sub,mult,div

def main():
    no1 = int(input("Enetr the first number :"))

    no2 = int(input("Enetr the second number :"))

    ret1,ret2,ret3,ret4=Arithmatic(no1,no2)

    print("Additon is :",ret1)
    print("Substraction :",ret2)
    print("Multiplication is :",ret3)
    print("Division :",ret4)

if __name__=="__main__":
    main()