""" Write a program which contains one function named as Fun(). That function should display 
“Hello from Fun” on console. """

def Fun():
    print("Hello From FUN")
    
def main():
    Fun()
    
if __name__=="__main__":
    main()
