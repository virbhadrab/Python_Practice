print("Jay Ganesh...")
print("Demonstration of for loop")

X = [10,20,"ABC","XYZ",30.1]

for i in X:
    print(i)

for i in range(0,9):
    print(i)