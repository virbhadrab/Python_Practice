print("-----Jay Ganesh -----")

print("Demonstrration of Break and Continue")

print("Demonstartion of break")

for i in range(0,9):
    if(i==3):
        break
    print(i)

print("Demonsatrtion of Continue")

for i in range(0,9):
    if(i == 3):
        continue
    print(i)