print("Jay  Ganesh...")

print("Demonstartion of while loop.")

i=1

while(i<5):
    print(i)
    i=i+1